playSound("assets/category_nature/forest_2.mp3", true);
onEvent("Draw", "click", function() {
	setScreen("Drawing");
	setActiveCanvas("DrawingCanvas");
	onEvent("DrawingCanvas", "mousemove", function(event) {
	  circle(event.x, event.y, 10);
	});
	onEvent("Maroon", "click", function( ) {
	  setFillColor("maroon");
	});
	onEvent("Teal", "click", function( ) {
	  setFillColor("teal");
	});
	onEvent("Black", "click", function( ) {
	  setFillColor("black");
	});
});
onEvent("Read", "click", function( ) {
	setScreen("screen2");
});
